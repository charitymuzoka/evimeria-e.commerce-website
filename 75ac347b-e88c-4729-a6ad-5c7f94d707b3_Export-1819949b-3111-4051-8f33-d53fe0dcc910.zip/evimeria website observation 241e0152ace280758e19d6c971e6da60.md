# evimeria website observation.

![1:  SEARCH BAR: it’s not working by simply not responsive to the searchings but rather nothing is displayed after searching.](abfd35e6-66d4-4fa3-8b40-67319040bc46.png)

1:  SEARCH BAR: it’s not working by simply not responsive to the searchings but rather nothing is displayed after searching.

![after login.png](after_login.png)

 2:  LOGIN: After accessing the form , the drop down content specifically the darshboard welcomes me with  a different name  instead of the one I used

![request b.png](request_b.png)

3:  REQUEST A QUOTE BUTTON: The button is not responding.

![view all.png](view_all.png)

4:  VIEW ALL QUOTES: This is not clickable too.

![Screenshot (192).png](Screenshot_(192).png)

6:  The page does not allow users to go back to  the previous page neither does it offer an option to go back to the home page 

![validation.png](validation.png)

7:  NO FORM VALIDATION:  The form does not offer proper form validation, it allows users to enter the choice of their details without being restricted.

![footer.png](footer.png)

![Screenshot (200).png](Screenshot_(200).png)

8: The footer specifically quick link part , they all do not display any information but instead shows the error provided aside.

![fulls.png](fulls.png)

9:  VISUAL JITTER:  The screen display or information display is not stable to fit the screen for users to see the entire page but rather requires you to move the screen to see the entire page in sides.

![zin.png](zin.png)

10:  GIFTING PAGE:  (1). Z-Index Issue: This refers to the stacking order of elements on a webpage, where elements with a higher z-index appear on top of those with a lower z-index.
(2). Layered Display Glitch: This term describes the phenomenon of multiple layers of information being displayed, with unclear or mixed visibility.
(3). Sticky Footer or Header Issue: This could be related to the behavior where the last visible information below is the one moving when you try to move the top information.

![Screenshot (213).png](Screenshot_(213).png)

11: The corporate page , has no product display.

![cop.png](cop.png)

12: nothing to be showed even after clicking them  both.

![click.png](click.png)

13: If you want to go back to your previous pages, there are no links provided to that section.

![aga.png](aga.png)

14

1. Footer Misrendering: This describes the footer section being displayed in an unexpected location, like the middle of the page.
2. Page Layout Glitch: This term captures the abnormal display behavior where the footer is shown in the middle, followed by the homepage content below.
3. Rendering Bug: This is a more general term that could apply to this unusual display issue, where the page isn't rendering in the expected order or layout.
4. Z-Index or Stacking Order Issue: This could also be related, if the footer is being rendered on top of other content due to a z-index or stacking order problem.